# SAG Java Client 

To see help message: 

``` python
python3 path-to-sag_client.py  help 
```


